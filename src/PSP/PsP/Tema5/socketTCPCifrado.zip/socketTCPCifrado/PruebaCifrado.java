package TCPCifrado;

public class PruebaCifrado {

	public static void main(String[] args) {
		Cifrado c = new Cifrado();
		String mensaje = "hola mundo";
		System.out.println(mensaje);
		String mensajeCifrado;
		try {
			mensajeCifrado = c.encrypt(mensaje);
			System.out.println(mensajeCifrado);
			String mensajeDescifrado=c.decrypt(mensajeCifrado);
			System.out.println(mensajeDescifrado);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
